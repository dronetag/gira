# Dep1

Dummy repo just for commit history log.

v1.0.0 initial commit
...    fix: grammar OCD-1234
v1.1.0 feat: add word for better explanation OCD-1234 #close
v1.1.1 fix: add new line at the end of file OCD-567
v1.1.2 chore: contains no JIRA ticket
